#!/bin/bash
# Enhanced script for Cybersecurity and System Analysis Toolkit

# Start SSH service
service ssh start

# Colors for better readability
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Get host IP for displaying in the banner
get_host_ip() {
    # Try multiple methods to obtain IP
    IP=$(hostname -I 2>/dev/null | awk '{print $1}') || \
    IP=$(ip -4 addr show eth0 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}') || \
    IP="<ip_host>"
    
    echo "$IP"
}

# Get the host IP
HOST_IP=$(get_host_ip)

# Create directories if they don't exist
for dir in "/home/security/workspace" "/home/security/tools" "/home/security/scripts" "/home/security/reports" "/home/security/data"; do
    [ ! -d "$dir" ] && mkdir -p "$dir" && chown security:security "$dir"
done

# Welcome message with better formatting
echo -e "${BLUE}===================================================================${NC}"
echo -e "${GREEN}      TOOLKIT DE CIBERSEGURIDAD Y ANÁLISIS DE SISTEMAS           ${NC}"
echo -e "${BLUE}===================================================================${NC}"
echo -e "   Acceso SSH: ssh security@${HOST_IP} -p 22"
echo -e "   Usuario: security"
echo -e "   Contraseña: security123"
echo -e "${BLUE}===================================================================${NC}"
echo -e "   Directorios principales:"
echo -e "   - /home/security/workspace  (directorio de trabajo)"
echo -e "   - /home/security/tools      (herramientas adicionales)"
echo -e "   - /home/security/scripts    (scripts útiles)"
echo -e "   - /home/security/reports    (informes y resultados)"
echo -e "   - /home/security/data       (datos persistentes)"
echo -e "${BLUE}===================================================================${NC}"
echo -e "${GREEN}         TOOLKIT INICIADO CORRECTAMENTE                          ${NC}"
echo -e "${BLUE}===================================================================${NC}"

# Keep the container running
tail -f /dev/null
